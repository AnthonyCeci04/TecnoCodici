public class CodiceCivile {
    public static void main () {

        String file_path = " ";



    }
}
