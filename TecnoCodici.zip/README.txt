LEGGERE ATTENTAMENTE!

1) Assicurati di avere Java 17 installato sul PC
Per farlo, apri il "Prompt dei comandi" ed esegui "java -version"

2) Esegui il software con "start.bat"


Se trovi dei bug, segnalali su Telegram a @NonSonoAntho